package io.testsheepnz.github;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

public class FirstTest {


    @Test
    public void firstTest() {
        System.setProperty("webdriver.chrome.driver", "/Users/jimin/Downloads/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();

        driver.get("https://testsheepnz.github.io/BasicCalculator.html");//Открываем ссылку
        

        WebElement Build = driver.findElement(By.id("selectBuild"));//Выбираем в первом вып.списке элемент Prototype
        Select build = new Select(Build);
        build.selectByValue("0");

        WebElement calc1 = driver.findElement(By.id("number1Field"));//Ввод в первой строке значения 2
        calc1.click();
        calc1.sendKeys("2");

        WebElement calc2 = driver.findElement(By.id("number2Field"));//Ввод во второй строке значения 3
        calc2.click();
        calc2.sendKeys("3");

        WebElement select1 = driver.findElement(By.id("selectOperationDropdown"));//Выбор во втором выпадающем списке значения
        Select select = new Select(select1);
        select.selectByValue("1");

        WebElement calculate = driver.findElement(By.id("calculateButton"));//кликаем кнопку Calculate
        calculate.click();

        WebElement value = driver.findElement(By.id("numberAnswerField"));
        System.out.println(value.getAttribute("value"));


        driver.quit();

    }

    @Test
    public void secondTest() {
        System.setProperty("webdriver.chrome.driver", "/Users/jimin/Downloads/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();

        driver.get("https://testsheepnz.github.io/BasicCalculator.html");//Открываем ссылку

        WebElement Build = driver.findElement(By.id("selectBuild"));//Выбираем в первом вып.списке элемент Prototype
        Select build = new Select(Build);
        build.selectByValue("0");

        WebElement calc1 = driver.findElement(By.id("number1Field"));//Ввод в первой строке значения 2
        calc1.click();
        calc1.sendKeys("gs");

        WebElement calc2 = driver.findElement(By.id("number2Field"));//Ввод во второй строке значения 3
        calc2.click();
        calc2.sendKeys("bu");

        WebElement select1 = driver.findElement(By.id("selectOperationDropdown"));//Выбор во втором выпадающем списке значения
        Select select = new Select(select1);
        select.selectByValue("4");

        WebElement calculate = driver.findElement(By.id("calculateButton"));//кликаем кнопку Calculate
        calculate.click();

        WebElement value = driver.findElement(By.id("numberAnswerField"));
        System.out.println(value.getAttribute("value"));


        driver.quit();


    }
    @Test
    public void thirdTest() {
        System.setProperty("webdriver.chrome.driver", "/Users/jimin/Downloads/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();

        driver.get("https://testsheepnz.github.io/random-number.html ");//Открываем ссылку


        WebElement Build = driver.findElement(By.id("buildNumber"));//Выбираем в первом вып.списке элемент Demo
        Select build = new Select(Build);
        build.selectByValue("0");

        WebElement calc1 = driver.findElement(By.id("rollDiceButton"));//кликаем Roll the Dice
        calc1.click();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


        WebElement calc2 = driver.findElement(By.id("numberGuess"));//Ищем строку для ввода строки
        calc2.click();
        calc2.sendKeys("string");

        WebElement submit = driver.findElement(By.id("submitButton"));//Кликаем кнопку Submit
        submit.click();


        WebElement value = driver.findElement(By.id("feedbackLabel"));
        System.out.println(value.getText());



        driver.quit();

    }

}
